package network

import retrofit2.Retrofit
import retrofit2.conventer.gson.GsonConventerFactory
class koneksi {
    compani object{
        val BaseUrl = "http://192.168.100.7/dabar/api/"
        val retrofit = Retrofit.Builder()
            .baseUrl(BaseUrl)
            .addConventerFactory(GsonConventerFactory.create())
            .build()
        val serveice:ApiService = retrofit.create(ApiService:class.java)
    }
}